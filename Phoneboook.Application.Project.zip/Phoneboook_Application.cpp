#include <iostream>
#include <map>
#include <string>
#include <algorithm>

using namespace std;

class Phonebook {
private:
    map<string, string> contacts;

public:
    void addContact(const string& name, const string& phoneNumber) {
        contacts[name] = phoneNumber;
    }

    void findContact(const string& name) {
        map<string, string>::iterator it = contacts.find(name);
        if (it != contacts.end()) {
            cout << "Name: " << it->first << " | Phone Number: " << it->second << endl;
        } else {
            cout << "Contact not found." << endl;
        }
    }

    void displayAllContacts() {
        cout << "All Contacts:" << endl;
        map<string, string>::iterator it;
        for (it = contacts.begin(); it != contacts.end(); ++it) {
            cout << "Name: " << it->first << " | Phone Number: " << it->second << endl;
        }
    }

    void displayAllContactsSortedByName(bool ascending = true) {
        cout << "Contacts sorted by name:" << endl;
        map<string, string>::iterator it;
        if (ascending) {
            for (it = contacts.begin(); it != contacts.end(); ++it) {
                cout << "Name: " << it->first << " | Phone Number: " << it->second << endl;
            }
        } else {
            map<string, string>::reverse_iterator rit;
            for (rit = contacts.rbegin(); rit != contacts.rend(); ++rit) {
                cout << "Name: " << rit->first << " | Phone Number: " << rit->second << endl;
            }
        }
    }
};

int main() {
    Phonebook phonebook;
    int choice;

    do {
        cout << "Phonebook Application" << endl;
        cout << "1. Add Contact" << endl;
        cout << "2. Find Contact" << endl;
        cout << "3. Display All Contacts" << endl;
        cout << "4. Display All Contacts Sorted by Name (Ascending)" << endl;
        cout << "5. Display All Contacts Sorted by Name (Descending)" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string name, phoneNumber;
                cout << "Enter Name: ";
                cin >> name;
                cout << "Enter Phone Number: ";
                cin >> phoneNumber;
                phonebook.addContact(name, phoneNumber);
                break;
            }
            case 2: {
                string name;
                cout << "Enter Name to find: ";
                cin >> name;
                phonebook.findContact(name);
                break;
            }
            case 3: {
                phonebook.displayAllContacts();
                break;
            }
            case 4: {
                phonebook.displayAllContactsSortedByName(true); 
                break;
            }
            case 5: {
                phonebook.displayAllContactsSortedByName(false); 
                break;
            }
            case 6:
                cout << "Exiting the application." << endl;
                break;
            default:
                cout << "Invalid choice. Please enter a valid choice." << endl;
        }

    } while (choice != 6);

    return 0;
}
